/*
 * Script de recherche et d'interactivité pour le livre de recettes
 * Ce script filtre les cartes de recettes en temps réel en fonction du
 * contenu recherché par l'utilisateur. Il n'effectue aucune requête
 * réseau afin de préserver les performances.
 */

document.addEventListener('DOMContentLoaded', () => {
  const searchInput = document.getElementById('recherche');
  if (!searchInput) return;
  const cards = Array.from(document.querySelectorAll('.recipe-card'));

  // Filtre les cartes à chaque frappe
  searchInput.addEventListener('input', () => {
    const term = searchInput.value.trim().toLowerCase();
    cards.forEach((card) => {
      const text = card.textContent.toLowerCase();
      if (text.includes(term)) {
        card.style.display = '';
      } else {
        card.style.display = 'none';
      }
    });
  });
});